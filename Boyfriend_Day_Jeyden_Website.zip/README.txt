BOYFRIEND DAY — JEYDEN

Cara pakai:
1. Buka index.html di browser untuk melihat website.
2. Untuk mengganti dua foto, edit bagian "YOUR PHOTO HERE" pada index.html.
   Cara paling mudah: ganti div photo-box dengan:
   <img src="foto1.jpg" alt="Our moment">
   lalu taruh foto1.jpg dan foto2.jpg di folder yang sama.
3. Website sudah responsif untuk HP.
4. Mini-games: Catch My Hearts, Crack the Web Code, dan Boyfriend Quiz.

Catatan:
- Kode rahasia saat ini: 143.
- Teks bisa kamu edit langsung di index.html.
